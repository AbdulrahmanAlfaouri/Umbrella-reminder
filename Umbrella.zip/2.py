from sys import argv
from PyQt5 import QtWidgets
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QDialog,QApplication


class wellcomescreen(QDialog):
        def __init__(self):
                super(wellcomescreen,self).__init__()
                loadUi(r"F:\UP\.Py\Umbrella reminder\2.ui",self)
                self.Button.clicked.connect(self.aaaaa)
        @pyqtSlot()
        def aaaaa(self):
                text = self.line.text()
                self.datxt.setText(text)


app = QApplication([])
mainWindow = wellcomescreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(mainWindow)
widget.setFixedWidth(400)
widget.setFixedHeight(300)
widget.show()
app.exec_()